#include<stdio.h>
#include<conio.h>
void main()
{
int a,b;
float c;
clrscr();
printf("enter the value of a");
scanf("%d",&a);
printf("enter the value of b");
scanf("%d",&b);
c=a*b;
printf("multi is %f",c);
getch();
}